import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // ✅ Login successful
                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                String sessionId = session.getId();

                // ✅ Redirect to DashboardServlet after 5 seconds
                response.setContentType("text/html");
                response.getWriter().println("<html><head>");
                response.getWriter().println("<meta http-equiv='refresh' content='5;url=DashboardServlet'>");
                response.getWriter().println("<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>");
                response.getWriter().println("</head><body class='d-flex justify-content-center align-items-center vh-100 bg-light'>");

                response.getWriter().println("<div class='card shadow-lg p-4 text-center' style='width: 350px;'>");
                response.getWriter().println("<h2 class='text-primary'>Welcome, " + username + "!</h2>");
                response.getWriter().println("<p class='text-muted'>Session ID: <strong>" + sessionId + "</strong></p>");
                response.getWriter().println("<p class='text-success fw-bold'>Redirecting to Dashboard...</p>");
                response.getWriter().println("<div class='spinner-border text-primary' role='status'><span class='visually-hidden'>Loading...</span></div>");
                response.getWriter().println("</div>");

                response.getWriter().println("</body></html>");
            } else {
                // ❌ Invalid login
                response.sendRedirect("login.html?error=Invalid Credentials");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("login.html?error=Database Error");
        }
    }
}
