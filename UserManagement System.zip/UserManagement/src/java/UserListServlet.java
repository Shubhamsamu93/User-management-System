import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/UserListServlet")
public class UserListServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<String[]> userList = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            // JDBC connection and query
            try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/user_management", "root", "shadab@8210");
                 PreparedStatement ps = conn.prepareStatement("SELECT id, username FROM users1");
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    String[] user = new String[2];
                    user[0] = String.valueOf(rs.getInt("id"));
                    user[1] = rs.getString("username");
                    userList.add(user);
                }
            }

        } catch (Exception e) {
            e.printStackTrace(); // Can be replaced with proper logging
        }

        request.setAttribute("userList", userList);
        request.getRequestDispatcher("dashboard.jsp").forward(request, response);
    }
}
